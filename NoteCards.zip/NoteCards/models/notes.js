const mongoose = require('mongoose');

const notesSchema = new mongoose.Schema({ 
    email: { type: String, required: true },
    title: { type: String, required: true },
    desc: { type: String, required: true }
});

const Note = mongoose.model('Note', notesSchema); // Changed 'notes' to 'Note' for better naming

module.exports = Note; // Export the Note model