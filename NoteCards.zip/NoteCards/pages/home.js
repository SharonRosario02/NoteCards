// js for processing post request from the client side to the server side
async function postData(url = "", data = {}) {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

// js for fetching all the notes on the email from the DB and displaying it
// this part was after notes were getting saved in the database
const fetchNotes = async () => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user && user.email) {
    try {
      const notes = await postData("/getnotes", { email: user.email });
      const reversedNotes = notes.notes.reverse();

      let notesHtml = "";
      reversedNotes.forEach((element) => {
        const descLines = element.desc.split("\n");
        const firstLine = descLines[0];
        const displayedDesc = firstLine.length > 20 ? firstLine.substring(0, 20) + "..." : firstLine;

        let note = `
          <div class="card" style="width: 18rem;">
            <div class="card-body">
              <h5 class="card-title">${element.title}</h5>
              <h6 class="card-subtitle mb-2 text-body-secondary" style="font-size:13px;">Description:</h6>
              <div class="line"></div>
              <p class="card-text">${displayedDesc}</p>
              <button type="button" class="card-link view-link" data-note-id="${element._id}">View</button>
              <button type="button" class="card-link update-link" style="margin:15px 0;" data-note-id="${element._id}">Update</button>
              <button type="button" class="card-link delete-link" style="margin:15px 0;"data-note-id="${element._id}">Delete</button>
            </div>
          </div>
        `;
        notesHtml += note;
      });

      let notesContainer = document.querySelector(".myNotes");
      notesContainer.innerHTML = notesHtml;

      // Add event listener after dynamic elements are present
      notesContainer.addEventListener("click", handleUpdateClick);
      notesContainer.addEventListener("click", handleDeleteClick);
      notesContainer.addEventListener("click", handleViewClick);
    } catch (error) {
      console.error("Error fetching notes:", error);
    }
  } else {
    // alert("Please login first");
    window.location.href = "/login";
  }
};

// Call fetchNotes once for initial loading
fetchNotes();

// Fetch the user object from localStorage
const user = JSON.parse(localStorage.getItem("user"));

// js for updating and adding notes
let submit = document.getElementById("submit");
submit.addEventListener("click", async () => {
  let title = document.getElementById("title").value;
  let desc = document.getElementById("desc").value;

  // Check if the button has a data-note-id attribute
  const noteId = submit.getAttribute("data-note-id");

  // Determine whether to add a new note or update an existing one
  if (noteId) {
    // Update existing note
    let response = await updateNote(noteId, title, desc);
    if (response.success) {
      // alert("Note updated");
      document.getElementById("title").value = "";
      document.getElementById("desc").value = "";
      submit.textContent = 'Save'
      const cancelButton = document.getElementById('cancel');
      cancelButton.remove();
      fetchNotes();
    } else {
      alert("Failed to update the note");
    }
  } else {
    // Add new note
    let data = { title, desc, email: user.email };
    let response = await postData("/addnote", data);
    if (response.success) {
      document.getElementById("title").value = "";
      document.getElementById("desc").value = "";
      fetchNotes();
    }
  }
});

// Set the data-note-id attribute on the "Submit" button when updating
function setNoteIdForUpdate(noteId) {
  submit.setAttribute("data-note-id", noteId);
}

// js for deleting notes
const handleDeleteClick = async (event) => {
  if (event.target.classList.contains("delete-link")) {
    console.log("Clicked on delete link");
    const noteId = event.target.getAttribute("data-note-id");
    const response = await deleteNote(noteId);
    if (response.success) {
      alert("Note deleted");
      fetchNotes();
    } else {
      alert("Failed to delete the note");
    }
  }
};

// js for viewing notes
const handleViewClick = (event) => {
  if (event.target.classList.contains("view-link")) {
    const noteId = event.target.getAttribute("data-note-id");
    window.location.href = `/view-note?noteId=${noteId}`;
  }
};

// js for updating notes
// Function to handle the update link click
// js for updating notes
// js for updating notes
const handleUpdateClick = async (event) => {
  try {
    // Check if the clicked element has the "update-link" class
    if (event.target.classList.contains("update-link")) {
      const submit = document.querySelector('#submit');
      submit.textContent = 'Update';

      // Get the note ID from the clicked element
      const noteId = event.target.getAttribute("data-note-id");

      // Fetch note details based on the note ID
      const response = await fetch(`/getnote?noteId=${noteId}`);
      const data = await response.json();

      if (data.success) {
        const note = data.note;

        // Set the existing title and description as the value of the input and textarea
        document.getElementById("title").value = note.title;
        document.getElementById("desc").value = note.desc;

        // Set the data-note-id attribute on the "Submit" button when updating
        setNoteIdForUpdate(noteId);

        // Add Cancel button dynamically
        const cancelButton = document.createElement('button');
        cancelButton.type = 'button';
        cancelButton.classList.add('button');
        cancelButton.id = 'cancel';
        cancelButton.innerHTML = '<p>Cancel</p>';
        cancelButton.addEventListener('click', () => {
          document.getElementById("title").value = "";
          document.getElementById("desc").value = "";
          submit.textContent = "Save";
          cancelButton.remove(); // Remove the Cancel button
        });

        const container = document.querySelector('.container.my-3');
        container.appendChild(cancelButton);
      } else {
        console.error("Error fetching note details:", data.error);
      }
    }
  } catch (error) {
    console.error("Error handling update click:", error);
  }
};


// js for logout
const logoutButton = document.getElementById("logout-button");
logoutButton.addEventListener("click", () => {
  // Clear user data from local storage or cookies
  localStorage.removeItem("user"); // Example for local storage
  // Redirect to the login page or another destination
  window.location.href = "/login"; // Redirect to the login page
});


// Function to update a note by its ID
const updateNote = async (noteId, updatedTitle, updatedDesc) => {
  const response = await fetch(`/updatenote/${noteId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ title: updatedTitle, desc: updatedDesc }),
  });
  return response.json();
};


// Function to delete a note by its ID
const deleteNote = async (noteId) => {
  const response = await fetch(`/deletenote/${noteId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  });
  return response.json();
};


// below code was added for implementing search bar functionality


// Function to display notes based on the search query
const displayNotes = (notes, searchTerm) => {
  const notesContainer = document.querySelector('.myNotes');
  const allNotes = notesContainer.querySelectorAll('.card');

  allNotes.forEach((note) => {
    const title = note.querySelector('.card-title').innerText.toLowerCase();
    const description = note.querySelector('.card-text').innerText.toLowerCase();

    if (title.includes(searchTerm) || description.includes(searchTerm)) {
      note.style.display = 'block';
    } else {
      note.style.display = 'none';
    }
  });
};

// Function to send a POST request to the server to fetch notes based on search query
const fetchNotesForSearchBar = async (searchQuery) => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user && user.email) {
    try {
      const response = await fetch("/getnotes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: user.email, searchQuery }),
      });

      if (response.ok) {
        const notes = await response.json();
        // Call a function to display the fetched notes
        displayNotes(notes, searchQuery);
      } else {
        console.error("Failed to fetch notes:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching notes:", error);
    }
  } else {
    // alert("Please login first");
    window.location.href = "/login";
  }
};

// Event listener for input field to trigger fetchNotesForSearchBar on input
const searchInput = document.querySelector(".input1");
searchInput.addEventListener("input", (event) => {
  const searchQuery = event.target.value;
  fetchNotesForSearchBar(searchQuery);
});

// Event listener to clear search bar and display all notes on click outside the search bar
document.addEventListener("click", (event) => {
  if (!searchInput.contains(event.target)) {
    searchInput.value = "";
    fetchNotesForSearchBar("");
  }
});

// The rest of your code, including defining postData, remains unchanged
// ...

