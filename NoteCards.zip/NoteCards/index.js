const mongoose = require("mongoose");
const express = require("express");
const path = require("path");
const app = express();
const Note = require("./models/notes");
const User = require("./models/user");
const { log } = require("console");
const router = express.Router();

// Use the correct middleware to handle URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const port = 3001;

mongoose
.connect("mongodb://localhost:27017")
.then(() => console.log("Connected"))
.catch((error) => console.error("Error:", error));

// Static file serving
// Serve static assets from the 'pages' directory
app.use('/static', express.static(path.join(__dirname, 'pages')));
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(express.static(path.join(__dirname, "pages")));
app.use('/css', express.static(path.join(__dirname, 'css')));

// Define route handlers for serving HTML pages
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "pages", "index.html"));
});


app.get("/sign-up", (req, res) => {
  res.sendFile(path.join(__dirname, "pages", "sign-up.html"));
});


app.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "pages", "login.html"));
  });

// Define route handlers for APIs
app.post("/login", async (req, res) => {
    // Implement login logic
    //searching for the user email and password entered by user in login page
    let user = await User.findOne(req.body);
    if(!user){
        res.status(200).json({success: false, message: 'user does not exist'})
    }else{
        res.status(200).json({success: true,user: {email: user.email}, message: 'user found'})
    }
});

//sign-up express handler which will handle http requests comming from client side 
// req is the incomming data from the client
// res is This object represents the HTTP response that your server will send back to the client.
app.post("/sign-up", async (req, res) => {
  try {
    // Check if the email is already in use
    const existingUser = await User.findOne({ email: req.body.email });
    if (existingUser) {
      // Email is already in use; return an error response
      return res.status(400).json({ success: false, error: "Email is already in use" });
    }
    const user = await User.create(req.body);
    console.log(req.body);
    console.log(user);
    res.status(200).json({ success: true, user });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ success: false, error: "User registration failed" });
  }
});

// add note when submit is clicked the client side sends a post request which is handled by this express handler
app.post("/addnote", async (req, res) => {
    // Implement logic to add a note
    try {
        const note = new Note(req.body);
        const savedNote = await note.save();
        res.status(200).json({ success: true, notes: savedNote });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// api to fetch all notes from mongodb and send as json
app.post("/getnotes", async (req, res) => {
  // Implement logic to get notes
  let notes = await Note.find({email:req.body.email}) 
  res.status(200).json({success: true,notes})
});


//chnaged for view.html page 

// Route to serve view-note.html
app.get('/view-note', (req, res) => {
  res.sendFile(path.join(__dirname, './pages/view-note.html'));
});

// Add a new endpoint to fetch a specific note based on noteId
app.get('/getnote', async (req, res) => {
  try {
    const noteId = req.query.noteId;
    const note = await Note.findById(noteId);

    if (!note) {
      return res.status(404).json({ success: false, error: 'Note not found' });
    }

    res.status(200).json({ success: true, note });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// app.use(express.static('images'));
// ...

app.delete("/deletenote/:id", async (req, res) => {
  try {
      const noteId = req.params.id;

      // Check if the note with the provided ID exists
      const note = await Note.findById(noteId);
      if (!note) {
          return res.status(404).json({ success: false, error: "Note not found" });
      }

      // If the note exists, delete it
      await Note.findByIdAndDelete(noteId);

      res.status(200).json({ success: true, message: "Note deleted successfully" });
  } catch (error) {
      res.status(500).json({ success: false, error: error.message });
  }
});


app.listen(port, () => {
  console.log(`App listening on http://localhost:${port}`);
});


// app.use('../router/router', router);


// Route to update a note by ID
app.put('/updatenote/:id', async (req, res) => {
  const noteId = req.params.id;
  const { title, desc } = req.body;

  try {
      // Use Mongoose or your preferred database library to update the note
      const updatedNote = await Note.findByIdAndUpdate(noteId, { title, desc }, { new: true });

      res.json({ success: true, updatedNote });
  } catch (error) {
      console.error('Error updating note:', error);
      res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});
